import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const TournamentApp());

class TournamentApp extends StatelessWidget {
  const TournamentApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FF Tournament',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFF6B00),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF101114),
        useMaterial3: true,
        cardTheme: const CardThemeData(
          color: Color(0xFF1B1D22),
          margin: EdgeInsets.zero,
        ),
      ),
      home: const TournamentHome(),
    );
  }
}

class Tournament {
  Tournament({
    required this.id,
    required this.title,
    required this.mode,
    required this.date,
    required this.entryFee,
    required this.prize,
    required this.slots,
    this.roomId = '',
    this.roomPassword = '',
    this.status = 'Upcoming',
  });

  final String id;
  String title;
  String mode;
  String date;
  int entryFee;
  int prize;
  int slots;
  String roomId;
  String roomPassword;
  String status;

  Map<String, dynamic> toJson() => {
    'id': id, 'title': title, 'mode': mode, 'date': date,
    'entryFee': entryFee, 'prize': prize, 'slots': slots,
    'roomId': roomId, 'roomPassword': roomPassword, 'status': status,
  };

  factory Tournament.fromJson(Map<String, dynamic> j) => Tournament(
    id: j['id'] as String,
    title: j['title'] as String,
    mode: j['mode'] as String,
    date: j['date'] as String,
    entryFee: j['entryFee'] as int,
    prize: j['prize'] as int,
    slots: j['slots'] as int,
    roomId: (j['roomId'] ?? '') as String,
    roomPassword: (j['roomPassword'] ?? '') as String,
    status: (j['status'] ?? 'Upcoming') as String,
  );
}

class TournamentHome extends StatefulWidget {
  const TournamentHome({super.key});
  @override
  State<TournamentHome> createState() => _TournamentHomeState();
}

class _TournamentHomeState extends State<TournamentHome> {
  int tab = 0;
  bool adminMode = false;
  List<Tournament> tournaments = [];
  Set<String> joined = {};
  List<String> results = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('tournaments');
    final joinedRaw = p.getStringList('joined') ?? [];
    final resultRaw = p.getStringList('results') ?? [];
    if (!mounted) return;
    setState(() {
      tournaments = raw == null
          ? [
              Tournament(id: 'demo1', title: 'Friday Night Clash', mode: 'Squad',
                date: '2026-11-06 20:00', entryFee: 0, prize: 500, slots: 48),
              Tournament(id: 'demo2', title: 'Solo Survival', mode: 'Solo',
                date: '2026-11-07 18:30', entryFee: 0, prize: 200, slots: 48),
              Tournament(id: 'demo3', title: 'Duo Rush', mode: 'Duo',
                date: '2026-11-08 19:00', entryFee: 0, prize: 300, slots: 24),
            ]
          : (jsonDecode(raw) as List)
              .map((e) => Tournament.fromJson(Map<String, dynamic>.from(e)))
              .toList();
      joined = joinedRaw.toSet();
      results = resultRaw;
    });
    if (raw == null) await _save();
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('tournaments',
        jsonEncode(tournaments.map((t) => t.toJson()).toList()));
    await p.setStringList('joined', joined.toList());
    await p.setStringList('results', results);
  }

  Future<void> _join(Tournament t) async {
    if (joined.contains(t.id)) {
      _message('You have already joined this demo tournament.');
      return;
    }
    setState(() => joined.add(t.id));
    await _save();
    _message('Joined locally. This starter does not submit data to a server.');
  }

  void _message(String text) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _createTournament() async {
    final title = TextEditingController();
    final mode = ValueNotifier<String>('Squad');
    final date = TextEditingController(text: '2026-11-10 20:00');
    final prize = TextEditingController(text: '500');
    final slots = TextEditingController(text: '48');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Create tournament'),
        content: SingleChildScrollView(child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: title, decoration: const InputDecoration(labelText: 'Tournament name')),
            const SizedBox(height: 8),
            ValueListenableBuilder<String>(valueListenable: mode, builder: (_, v, __) =>
              DropdownButtonFormField<String>(
                value: v, decoration: const InputDecoration(labelText: 'Mode'),
                items: ['Solo', 'Duo', 'Squad'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
                onChanged: (x) { if (x != null) mode.value = x; },
              )),
            TextField(controller: date, decoration: const InputDecoration(labelText: 'Date and time')),
            TextField(controller: prize, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Prize (demo amount)')),
            TextField(controller: slots, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Player slots')),
          ],
        )),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Create')),
        ],
      ),
    );
    if (ok != true || title.text.trim().isEmpty) return;
    final t = Tournament(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: title.text.trim(), mode: mode.value, date: date.text.trim(),
      entryFee: 0, prize: int.tryParse(prize.text) ?? 0,
      slots: int.tryParse(slots.text) ?? 48,
    );
    setState(() => tournaments.insert(0, t));
    await _save();
    _message('Tournament saved on this device.');
  }

  Future<void> _setRoom(Tournament t) async {
    final id = TextEditingController(text: t.roomId);
    final password = TextEditingController(text: t.roomPassword);
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: Text('Room details · ${t.title}'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: id, decoration: const InputDecoration(labelText: 'Room ID')),
        TextField(controller: password, decoration: const InputDecoration(labelText: 'Room password')),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
      ],
    ));
    if (ok != true) return;
    setState(() { t.roomId = id.text.trim(); t.roomPassword = password.text.trim(); });
    await _save();
  }

  Future<void> _publishResult() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Publish result'),
      content: TextField(controller: c, decoration: const InputDecoration(labelText: 'Result / winner details')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Publish')),
      ],
    ));
    if (ok != true || c.text.trim().isEmpty) return;
    setState(() => results.insert(0, c.text.trim()));
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homePage(),
      _joinedPage(),
      _resultsPage(),
      _profilePage(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.sports_esports, color: Color(0xFFFF6B00)),
          SizedBox(width: 8),
          Text('FF TOURNAMENT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1)),
        ]),
        actions: [
          IconButton(
            tooltip: adminMode ? 'Switch to player view' : 'Admin demo mode',
            onPressed: () => setState(() => adminMode = !adminMode),
            icon: Icon(adminMode ? Icons.admin_panel_settings : Icons.shield_outlined),
          ),
        ],
      ),
      body: pages[tab],
      floatingActionButton: adminMode && tab == 0
          ? FloatingActionButton.extended(
              onPressed: _createTournament,
              icon: const Icon(Icons.add),
              label: const Text('Create'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.confirmation_number_outlined), selectedIcon: Icon(Icons.confirmation_number), label: 'Joined'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events), label: 'Results'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _homePage() => ListView(
    padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(colors: [Color(0xFF632A0A), Color(0xFF25170F), Color(0xFF1B1D22)]),
        ),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('BATTLE. SURVIVE. WIN.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          SizedBox(height: 8),
          Text('Join community tournaments and climb the leaderboard.'),
          SizedBox(height: 12),
          Chip(avatar: Icon(Icons.local_fire_department), label: Text('FREE ENTRY DEMO')),
        ]),
      ),
      const SizedBox(height: 22),
      Row(children: [
        const Expanded(child: Text('Upcoming tournaments', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        Text('${tournaments.length} matches', style: TextStyle(color: Colors.grey.shade400)),
      ]),
      const SizedBox(height: 12),
      if (tournaments.isEmpty) const Text('No tournaments yet.'),
      ...tournaments.map(_tournamentCard),
      if (adminMode) ...[
        const SizedBox(height: 20),
        const Text('Admin tools', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        ...tournaments.map((t) => Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: OutlinedButton.icon(
            onPressed: () => _setRoom(t),
            icon: const Icon(Icons.vpn_key),
            label: Text('Set room details: ${t.title}'),
          ),
        )),
        FilledButton.tonalIcon(onPressed: _publishResult, icon: const Icon(Icons.publish), label: const Text('Publish result')),
        const SizedBox(height: 8),
        const Text('Admin mode is only a local UI demo. It has no authentication or server-side security.',
          style: TextStyle(color: Colors.orangeAccent)),
      ],
    ],
  );

  Widget _tournamentCard(Tournament t) {
    final isJoined = joined.contains(t.id);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: const Color(0xFFFF6B00).withOpacity(.16), borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.sports_martial_arts, color: Color(0xFFFF8A33)),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t.title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              Text('${t.mode} • ${t.date}', style: TextStyle(color: Colors.grey.shade400)),
            ])),
            Chip(label: Text(t.status)),
          ]),
          const SizedBox(height: 16),
          Row(children: [
            _stat('ENTRY', t.entryFee == 0 ? 'FREE' : '৳${t.entryFee}'),
            _stat('PRIZE', '৳${t.prize}'),
            _stat('SLOTS', '${joined.contains(t.id) ? 1 : 0}/${t.slots}'),
          ]),
          if (adminMode && (t.roomId.isNotEmpty || t.roomPassword.isNotEmpty)) ...[
            const Divider(height: 24),
            SelectableText('Room ID: ${t.roomId}\nPassword: ${t.roomPassword}'),
          ],
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: FilledButton(
            onPressed: isJoined ? null : () => _join(t),
            child: Text(isJoined ? 'JOINED' : 'JOIN TOURNAMENT'),
          )),
        ]),
      ),
    );
  }

  Widget _stat(String label, String value) => Expanded(child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label, style: TextStyle(fontSize: 10, color: Colors.grey.shade500, letterSpacing: 1)),
      const SizedBox(height: 4),
      Text(value, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
    ],
  ));

  Widget _joinedPage() {
    final list = tournaments.where((t) => joined.contains(t.id)).toList();
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('My tournaments', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      if (list.isEmpty) const Card(child: Padding(
        padding: EdgeInsets.all(20),
        child: Text('You have not joined a tournament yet. Open Home and tap Join Tournament.'),
      )),
      ...list.map((t) => Card(child: ListTile(
        leading: const Icon(Icons.sports_esports, color: Color(0xFFFF6B00)),
        title: Text(t.title), subtitle: Text('${t.mode} • ${t.date}'),
        trailing: const Icon(Icons.check_circle, color: Colors.green),
      ))),
    ]);
  }

  Widget _resultsPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Results & leaderboard', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    if (results.isEmpty) const Card(child: Padding(
      padding: EdgeInsets.all(20),
      child: Text('No results published yet. Admin demo mode can publish sample results.'),
    )),
    ...results.asMap().entries.map((e) => Card(child: ListTile(
      leading: CircleAvatar(child: Text('${e.key + 1}')),
      title: Text(e.value),
      subtitle: const Text('Admin-published result'),
    ))),
  ]);

  Widget _profilePage() => ListView(padding: const EdgeInsets.all(16), children: [
    const CircleAvatar(radius: 38, child: Icon(Icons.person, size: 40)),
    const SizedBox(height: 12),
    const Center(child: Text('Guest Player', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
    const Center(child: Text('Starter profile • no account connected')),
    const SizedBox(height: 20),
    Card(child: Column(children: [
      const ListTile(leading: Icon(Icons.badge_outlined), title: Text('Free Fire UID'), subtitle: Text('Not set up in this demo')),
      const Divider(height: 1),
      const ListTile(leading: Icon(Icons.privacy_tip_outlined), title: Text('Privacy & safety'), subtitle: Text('Add a privacy policy before public release')),
      const Divider(height: 1),
      ListTile(leading: const Icon(Icons.storage_outlined), title: const Text('Local data'), subtitle: const Text('Stored on this device only'), onTap: () => _message('Connect a secure backend for shared tournament data.')),
    ])),
    const SizedBox(height: 12),
    const Text('This is a starter app, not an official Garena product. Use only authorized game assets and follow tournament, payment, and app-store rules.',
      style: TextStyle(color: Colors.grey)),
  ]);
}
